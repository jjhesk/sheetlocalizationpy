
class Translation(object):
    def __init__(self):
        self.androidKey = None
        self.iosKey = None
        self.comment = None
        self.groupComment = None
        self.translations = []

