class CommentLineError(Exception):
    pass


class TransformError(Exception):
    pass
