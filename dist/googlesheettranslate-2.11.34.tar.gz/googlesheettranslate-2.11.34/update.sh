#!/bin/sh
. ./n.sh

fined
gitpush
instruction