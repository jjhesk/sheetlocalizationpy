from .itransformer import InterfaceTransform


class PyLan(InterfaceTransform):
    def __init__(self):
        """ implementation of interface transformation """
        super().__init__()
