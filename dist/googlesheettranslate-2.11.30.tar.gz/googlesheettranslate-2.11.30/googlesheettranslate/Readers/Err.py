class CommentLineError(Exception):
    pass


class TransformError(Exception):
    pass


class WrongReaderType(TypeError):
    pass
